export const WEATHER_API_URL = 'http://api.weatherapi.com/v1/forecast.json?key=0ba6f250e84d4767a0590004220610&q=';
export const ADRESS_API_URL = 'https://api.ipify.org/?format=json';
export const GEOLOCATION_API_URL = 'http://www.geoplugin.net/json.gp?ip=';